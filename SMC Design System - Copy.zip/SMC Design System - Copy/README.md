# SMC Design System

> **Version 6.2 · 2026-05-01 · Internal use.**
> Single canonical brand contract for **Saudi Motorsport Company (SMC)** — orchestrator of Saudi Arabia's motorsport ecosystem.
> Consolidates the v5.0 PPTX guideline + the live token YAML + the institutional PPTX engineering rules into one system.
> **v6.1 (2026-04-26):** added Portrait A4 templates for reports, charters, policies, and signed documents. See `slides/portrait/` and `tokens/smc-brand.yaml` §22.
> **v6.2 (2026-05-01):** added **Minister-grade tier** under the Government sub-brand — the highest deference tier in the SMC severity ladder (working team < CEO < Board < Minister). Codified from the HRH-approved JCC Land Options deck (vF260429). See `MINISTER-GRADE-CHECKLIST.md`, `tokens/smc-brand.yaml` §13b, and `assets/minister-grade/` for visual references.

---

## Brand position

> SMC is not a race organizer. It is the **orchestrator** of Saudi Arabia's motorsport ecosystem.

Three pillars:
1. **Premium & Executive** — CEOs, boards, government stakeholders. Every touchpoint earns trust.
2. **Performance-led** — world-class motorsport. Design carries energy, precision, confidence.
3. **Ecosystem scale** — races, venues, infrastructure, services, hospitality. The palette flexes across all.

**Why Dark Teal anchors the brand.** It signals trust, control, sophistication, institutional maturity. It is a leadership color, not a racing color. That distinction is the foundation.

---

## Source-of-truth precedence (LOCKED 2026-04-26)

```
   ┌──────────────────────────────────────────────────┐
   │  1. tokens/smc-brand.yaml      ← canonical       │
   │     • machine-readable contract                  │
   │     • all values · 21 numbered sections          │
   │     • agents, build scripts, lints read here     │
   └──────────────────────────────────────────────────┘
                       │ regenerates
                       ▼
   ┌──────────────────────────────────────────────────┐
   │  2. README.md (this file)      ← human-readable  │
   │     • narrative expression of the YAML           │
   │     • audience: designers, writers, reviewers    │
   └──────────────────────────────────────────────────┘
                       │ regenerates
                       ▼
   ┌──────────────────────────────────────────────────┐
   │  3. colors_and_type.css        ← CSS layer       │
   │     • web preview tokens                         │
   │     • drop-in for HTML mockups                   │
   └──────────────────────────────────────────────────┘

   ┌──────────────────────────────────────────────────┐
   │  4. ../old/SMC_Brand_Guideline_new.pptx          │
   │     • visual reference, archived                 │
   │     • DO NOT EDIT — frozen v5.0 PPTX             │
   └──────────────────────────────────────────────────┘
```

---

## Contents

| Path | Purpose |
|---|---|
| [`README.md`](README.md) | This file — narrative brand expression. |
| [`SKILL.md`](SKILL.md) | Claude skill descriptor (`smc-design`). |
| [`MINISTER-GRADE-CHECKLIST.md`](MINISTER-GRADE-CHECKLIST.md) | **Mandatory** when audience tier = Minister (HRH / royal / ministerial). Pre-flight + mid-flight + post-flight checks codified from the HRH-approved deck. |
| [`BUILD-SAFETY.md`](BUILD-SAFETY.md) | **Mandatory** PPTX engineering contract — B01–B13 bug catalog, required helpers, post-build pipeline. |
| [`NAMING.md`](NAMING.md) | File naming convention for SMC deliverables. |
| [`tokens/smc-brand.yaml`](tokens/smc-brand.yaml) | **Canonical** machine-readable design contract (21 sections). |
| [`colors_and_type.css`](colors_and_type.css) | CSS variables — colors, type, spacing, gradients, motion. |
| [`lib/safe-helpers.js`](lib/safe-helpers.js) | `safeW` · `safeH` · `safeFont` · `safeBounds` · `inSafeZone` · `scaledFont` · `hRule` · `vRule` · `tableShapeGrid` · `guard`. |
| [`lib/coordinate-bridge.js`](lib/coordinate-bridge.js) | One conversion law: 1″ = 96 px = 72 pt = 914,400 EMU. Applied uniformly. |
| [`assets/`](assets) | Logo files (full color · black · white · mark). |
| [`fonts/`](fonts) | Font fallback notes (drop licensed `.woff2` here). |
| [`preview/`](preview) | HTML preview pages — open `preview/index.html` to browse. |
| [`slides/`](slides) | 13 slide templates — open `slides/index.html` to browse. |
| [`ui_kits/`](ui_kits) | (Stub — SMC has no software product in scope yet.) |

---

## Content fundamentals

### Voice

**Decisive · Precise · Authoritative · Purposeful.**
SMC speaks as the **platform and orchestrator**, never as a supporting event organizer.

- **Decisive** — takes a position. Never hedges. No "it depends" without a recommendation.
- **Precise** — numbers, facts, timelines. Every claim grounded in evidence.
- **Authoritative** — speaks as the governing body. Never a supporting vendor.
- **Purposeful** — every sentence earns its place. No filler, no motivational tone.

### Casing

- **UPPERCASE with wide letterspacing (0.22 em)** for section labels, eyebrows (e.g. `SECTION 01`, `BRAND PHILOSOPHY`, `USE`).
- **Title Case** for headlines and slide titles.
- **Sentence case** for body and descriptions.
- **Never** ALL CAPS for body text.

### Punctuation

- Em-dash `—` for phrase-level separation, en-dash `–` for ranges.
- **Middle dot `·`** is the canonical metadata separator: `SMC Brand Guideline  ·  v6.0  ·  2026  ·  Internal Use`.
- **Arrow `→`** leads every body bullet.
- **Check `✓` / cross `✗`** for do/don't lists.
- Double space around separators in metadata lines.

### Vocabulary

`ownership` · `mandate` · `governance` · `operating model` · `maturity` · `accountability` · `sequencing` · `dependency` · `visibility` · `alignment` · `escalation` · `delivery`

### Strip these out

| Don't say | Say instead |
|---|---|
| Exciting journey | Structured programme |
| World-class experience | Executive-grade delivery |
| Moving forward | From [date] / in Phase 2 |
| Stakeholder synergy | Name the specific dependency |
| It was a great success | Quantify the outcome |

### Arabic

Arabic register matches the executive English tone — formal, precise, idiomatic. **Avoid literal translation.** Arabic is set in **Sakkal Majalla** at **+15% size** vs the English equivalent. See `tokens/smc-brand.yaml` §5 `fonts.arabic_size_factor`. For bilingual layouts, see slides 09 / 10 / 11 (`preview/sub-brands.html` for sub-brand sub-rules).

### Emoji

**Never.** The brand uses geometric markers (`→ ✓ ✗ ·`) and numerals instead. See [§16 icons](tokens/smc-brand.yaml) for the typographic + Lucide tiered system.

---

## Visual foundations

### Color

| Weight | Color | Hex | Status |
|---|---|---|---|
| 60% | Dark Teal — anchor | `#00625B` | 🔒 LOCKED |
| 20% | Off-White — content bg | `#FAFAF8` | — |
| 12% | Asphalt — premium dark | `#141414` | — |
| 5% | Dune — warm panel | `#EDE7DB` | — |
| 3% | Championship Gold — accent | `#C59A3C` | — |

**Forest Green `#009667`** is co-equal to Dark Teal and 🔒 LOCKED. Used for KPI numbers, accent bars, event-energy contexts.

**Permanently excluded:** Copper · red-saturated racing-cliché reds. Electric Lime is digital-event-only.

**Max 3 colors per slide.** One dominant accent per slide — never competing.

### Four approved combinations

- **Executive Dark** — Teal/Asphalt cover · Gold accent → cover & section dividers
- **Clean Light** — Off-White bg · Teal anchor → content & data (default)
- **Desert Warm** — Dune bg · Teal anchor · Gold sparing → field / venue / hospitality
- **Premium Dark** — Asphalt dominant · Gold + Teal accents → closing / highlights

### Typography — extended scale

**English: Century Gothic** (fallback Jost). **Arabic: Sakkal Majalla** (fallback Cairo). Logo wordmark uses Rotunda + Cairo. **No substitutions permitted.**

| Tier | PPTX (pt) | Web (px) | Use |
|---|---|---|---|
| Hero XL | 120 | 160 | Premium-gold milestone numerics |
| Hero L | 84 | 112 | Cover slide hero title |
| Section | 96 | 128 | Section-divider name |
| Display | 38 | 56 | Standard slide hero title |
| Heading | 26 | 36 | Slide title |
| Subheading | 18 | 22 | Card / section label |
| KPI | 54 | 72 | KPI metric value |
| Body | 13 | 16 | Paragraph copy |
| Caption | 9 | 11 | Sources, footers |
| Eyebrow | 10 | 12 (ls 0.22em) | Eyebrow / label |
| Metadata | 9 | 11 (ls 0.22em) | Top nav, footer text |

Rules: max 6 lines per content block · max 8 words per bullet · no all-caps body · no Arial substitutions.

### Spacing and layout

- **0.5″ (≈ 48 px on 1280×720) slide margins.**
- **8 pt grid** — all spacing tokens are multiples of 8.
- Consistent gaps · one idea per slide · strong whitespace.
- **Safe zones** are mandatory — see below.

### Safe zones — title lives INSIDE them (H-04 update)

The upper safe zone is intentionally generous (≈ 0.95″) so it can host the slide title block — not sit empty. Two title-frame patterns:

- **Hairline title** — title block sits on the cream page bg; a 0.75 pt teal hairline separates title from body.
- **Band title** — title block fills the upper safe zone with a Dune-toned band; topped by a 2 pt gold rule.

```
┌──────────────────────────────────────┐ y = 0
│ Gold top bar (10 px)                 │
├──────────────────────────────────────┤ y = 0.10
│                                      │
│   TITLE BLOCK (eyebrow + h1 + lede)  │  ← upper safe zone (band or hairline)
│                                      │
├──────────────────────────────────────┤ y = 1.85   hairline rule  ·  or band edge
│                                      │
│   BODY (free composition)            │  ← content_zone.body
│                                      │
├──────────────────────────────────────┤ y = 6.05
│   Callout band (optional)            │
├──────────────────────────────────────┤ y = 6.97
│   Footer band (Dune · 0.48″)         │
└──────────────────────────────────────┘ y = 7.50
   x=0   ······ left safe ······   x=12.93   right safe   x=13.333
```

**Every non-chrome shape** must satisfy `inSafeZone(x, y, w, h)` from `tokens/smc-brand.yaml#safe_zones`.

### Subtle gradient policy (NEW · Moe-approved 2026-04-26)

**Default = flat fill first.** Gradients are reserved for soft-touch refinement — never decorative noise.

✓ Allowed (4 named locations only):
1. **Gold button hover** — subtle metallic linear gradient, max 8% lightness delta.
2. **Premium-Gold callout slide** — radial atmospheric depth on Asphalt, opacity ≤ 0.18.
3. **Cover slide diagonal-line texture** — opacity ≤ 0.08 (invisible from > 2 m).
4. **Photography protection scrim** — for type legibility on imagery.

✗ Forbidden:
- Body content card backgrounds · KPI block backgrounds · footer band · default buttons · chart axis lines · table cell fills · text fills.

**No drop shadows. No glows.** Depth comes from hairlines and color blocks — that's the SMC discipline.

Tokens: `--grad-gold-button` · `--grad-premium-asphalt` · `--grad-photo-scrim` (in `colors_and_type.css`).

### Borders, radii, motion

- **Corner radii** — broadly sharp (`--r-0`). Buttons / tags only get 2 px (`--r-1`).
- **Borders** — 1 pt hairlines (`--smc-hairline`) for partitions; 2 pt gold (`--rule-gold`) for header underlines.
- **Animation** — fast fades only (120–200 ms, ease-out). No bounces, no decorative motion.
- **Hover** — darken fill 8–10% or shift to teal tint. **No glow.**

### Backgrounds

- **No gradients on bodies / cards / KPI blocks** (see policy above).
- Photography is overlaid with a flat dark scrim (40–70%) when type sits on it.
- Dark backgrounds = covers & dividers only. Content is always on Off-White or Dune.

---

## Tables — the rule of thumb (NEW · Moe-mandated 2026-04-26)

> Every SMC table is a **GRID OF SHAPES**, not pptxgenjs's `addTable`.

**Why.** `addTable` wraps cells in one frame; per-cell control over padding, borders, fills, and numeric alignment is limited; cells overflow declared widths. As a SHAPE GRID, every cell is its own RECTANGLE + TEXT BOX — pixel-precise alignment, brand-true fills, hairline borders, and zero overflow surprises.

**Pattern (locked in [`tokens/smc-brand.yaml`](tokens/smc-brand.yaml) §12):**

1. Use `lib/safe-helpers.js#tableShapeGrid()`. Reach for `addTable()` only for transparent data dumps where layout precision doesn't matter.
2. **Header is a single full-width filled RECTANGLE** (Teal fill, Off-White text). No per-column header cells — visually the header is a continuous band.
3. **Body cells share borders** (no inter-cell gap). Hairline weight 0.5 pt.
4. **Alt-row fill** = Teal-tint (cream tables) or `rgba(255,255,255,0.03)` (dark tables). Apply to even rows only.
5. **Numeric cells** — right-aligned · monospace · `--smc-teal-deep` color (or Gold for highlight rows).
6. **Status pills** — Green-tint (operational), Gold-tint (in-progress), light-red (blocked).
7. **Cell heights** — header 0.50″ · body 0.45″ · cell padding 0.16″ × 0.10″.

See `slides/12-data-table-shapes.html` for the canonical render and `preview/data-viz.html` for token-by-token spec.

---

## Build safety — non-negotiable

Every SMC PPTX MUST run the post-build pipeline before declaring done:

```
build script (uses safe-helpers wrappers)
        │
        ▼
pptx_fix.py    (.claude/skills/pptx-repair/)
        │   patches B01 phantom-CT, B02 zero-dim,
        │           B04b negative-dim, B03 rightTriangle
        ▼
lint_layout.py
        │   catches B09 overflow, B10 off-canvas, B11 chrome-zone,
        │           B12 overlap, B13 scaling text
        │   block ship on L1 (off-canvas) / L2 (chrome-zone)
        ▼
multi-probe render check
        │   python-pptx structural · PowerPoint COM SaveAs PDF
        │   LibreOffice fallback · Spire last resort (page-count guarded)
        ▼
markitdown content-fidelity diff
        ▼
✓ ship
```

Full bug catalog and required helpers: [`BUILD-SAFETY.md`](BUILD-SAFETY.md).

---

## Iconography

SMC is **geometric-marker-first**:

- **Arrow** `→` — leads every body bullet.
- **Middle dot** `·` — metadata separator (wide-spaced).
- **Check** `✓` — do-list (Forest Green).
- **Cross** `✗` — don't-list (red-on-light or near-black).
- **Numerical badges** `01 · 02 · 03` — Gold or Teal numbered blocks for sections.
- **Photo marker** `▣` — image slot placeholder.
- **Vertical rule** `|` — co-brand separator.

Where typographic markers don't suffice (web/dashboard contexts only), use **Lucide** at 1.75 px stroke from the approved 10-icon subset (see [§16 icons](tokens/smc-brand.yaml)).

Logo files: `assets/smc-logo-2024.png` (official, full-color), `assets/smc-logo-white.png` (reversed), `assets/smc-logo-black.png` (single-ink), `assets/smc-mark-teal.png` (mark only).

---

## Sub-brand matrix (NEW)

Same palette, different emphasis per audience:

| Sub-brand | Dominant | Footer left | Typical slide types |
|---|---|---|---|
| **EPMO** (default) | Teal | `SMC · EPMO` | content_standard_hairline, dual_pillar, three_column, infographic_slot, table_structured |
| **EMO** (events ops) | Teal · Green | `SMC · EMO` | content_standard_band, three_column, infographic_slot, data_dashboard |
| **Live Event** | Green · Teal | `SMC · Live Event` | cover, section_divider, metric_hero, data_dashboard, closing |
| **Hospitality** | Dune · Teal | `SMC · Hospitality` | cover, content_standard_band, three_column, metric_hero |
| **Corporate** | Teal · Gold | `SMC · Corporate` | cover, content_standard_hairline, dual_pillar, table_structured, closing |
| **Government** (stakeholder tier) | Teal · Asphalt · bilingual | `SMC · Government Liaison` | bilingual_cover, bilingual_content, bilingual_exec_brief, table_structured |
| **Government** ([Minister tier](MINISTER-GRADE-CHECKLIST.md)) | Teal · Asphalt · Arabic-end-to-end | شركة رياضة المحركات السعودية | content_standard_hairline (Arabic-only), section_divider (gold-numeral), minister_decision_ask, minister_thank_you, appendix_wrapper |

See [`preview/sub-brands.html`](preview/sub-brands.html) for stakeholder-tier examples and [`MINISTER-GRADE-CHECKLIST.md`](MINISTER-GRADE-CHECKLIST.md) for the Minister-tier contract (codified from the HRH-approved JCC Land Options deck, 2026-04-29).

## Minister-grade tier (v6.2 · 2026-05-01)

**When to use:** Audience is HRH, the Royal Family, the Minister of Sport in their official capacity, or equivalent royal/ministerial seat.

**What changes vs default Government stakeholder tier:**

| Dimension | Stakeholder tier | Minister tier |
|---|---|---|
| Cover | EN+AR bilingual; audience-aware | Arabic-led; **NO audience mention** ever; institutional title only |
| Content headlines | Display titles (38pt, label or sentence) | **Always full executive sentence** in Sakkal Majalla Bold 26pt, color `teal_ink #002E2B` |
| Footer (main flow) | "SMC · Government Liaison" + "Confidential — Internal Use" (English) | "شركة رياضة المحركات السعودية" + "سري — للاستخدام الداخلي" (Arabic end-to-end) |
| Decision close | Generic "Decisions / Next Steps" | `minister_decision_ask` slide: title "توجيه سموكم الكريم" + "الموافقة على..." lines + opt-out clause "أو التوجيه بما يراه سموكم" |
| Thank-you close | "شكراً" / "Thank You" | `minister_thank_you` slide: "شكرا لسموكم" or "شكرا لمعاليكم" — never plural-formal |
| Appendix | Inline content or short page | `appendix_wrapper` slides: source decks embed as page-stamped images with EN eyebrow + AR pagination; main story stays at 16-20 native slides |
| Quality gates | Standard SMC build pipeline | + 8 Minister-grade gates (Headline Pattern, Audience, Decision-Ask, Thank-You, Chrome, Appendix, Eyebrow, Identity) |

**Visual references:** `assets/minister-grade/` — 20 PNG renders of the HRH-approved deck + 7 baseline before/after pairs in `before-after/`.

**Tokens:** `tokens/smc-brand.yaml` §13b `minister_grade` (full machine-readable contract) and §10 slide types `minister_decision_ask`, `minister_thank_you`, `appendix_wrapper`.

---

## Portrait A4 templates (v6.1 · 2026-04-26)

Portrait A4 (8.27″ × 11.69″) is the canonical orientation for **reports, charters, policies, and any document requiring sign-off**. Easier to manage as PowerPoint than Word — visual control, brand consistency, signature blocks placed exactly, PDF export consistency.

### PowerPoint setup — print-clean A4

**Set the slide size BEFORE building.** Otherwise PowerPoint stretches/scales on print and the geometry breaks.

1. **Design** tab → **Slide Size** → **Custom Slide Size…**
2. Slides sized for: **A4 Paper (210 × 297 mm)**
3. Orientation: **Portrait** · Notes: **Portrait**
4. If asked about scaling: **Maximize** (preserves layout)
5. Verify: width = `21 cm` · height = `29.7 cm` · = `8.27 × 11.69 in`

```js
// pptxgenjs
pres.layout = 'A4_PORTRAIT';
pres.defineLayout({ name: 'A4_PORTRAIT', width: 8.27, height: 11.69 });
```

```python
# python-pptx
prs.slide_width  = Inches(8.27)
prs.slide_height = Inches(11.69)
```

### Portrait-only rules (everything else inherits from v6.0)

| Rule | Value |
|---|---|
| Outer L/R margin | 0.75″ (vs landscape 0.40″) |
| Title zone | **Fixed 1.40″ height** with `overflow:hidden` — content cannot bleed past the rule |
| Top safe y | 0.50″ |
| Bottom safe y | 11.19″ |
| Body grid | **1-col (6.77″) or 2-col (3.21″ each) — 3-col forbidden** |
| Signature zone | 1.30″ above footer (1.50″ for 3-up) |
| **GANTT axis** | **Always 3 columns** — units adapt (years · quarters · months) |
| **Org structure** | **3 leads per fold; far-left riser for ≥4 leads, no fold limit** |

### Templates available

`slides/portrait/`:
- `01-cover.html` — Document cover with title block + 4-item metadata + 3-up signature
- `02-summary.html` — 1-page summary · objective · scope · KPIs · 4-stat strip
- `03-gantt.html` — Milestone timeline · 3-column axis · stage-gates
- `04-stakeholders-table.html` — Table-as-shapes + Power × Interest map
- `05-org-standard.html` — Org structure with ≤3 workstream leads
- `06-org-wide.html` — Org structure with ≥4 workstream leads · far-left riser overflow

`preview/`:
- `portrait-canvas.html` — canvas, margins, safe zones, PowerPoint setup
- `portrait-title-patterns.html` — Hairline + Band title patterns + body grid
- `portrait-signing.html` — 3 signature patterns + footer + classification states
- `portrait-components.html` — Tables · GANTT (3-column rule) · Org (standard + wide)

---

## Caveats (still open)

1. **Companion 2024 PDF missing.** Logo clear-space rule is captured in `tokens/smc-brand.yaml` §14 from the v5.0 PPTX, pending the official 2024 PDF.
2. **Logo is a typographic recreation.** Replace with the official SVG when supplied.
3. **Font substitution.** Until licensed `.woff2` files land in `fonts/`, the system falls back to Jost (EN) and Cairo (AR). The `@font-face` block in `colors_and_type.css` is ready to activate.
4. **No embedded photography.** Brand specifies image styles; placeholder imagery awaits the SMC photo library.
5. **No native UI kit.** SMC's scope is presentations + physical/digital brand applications. If a website or dashboard codebase exists, it can be added.

---

**Ask:** if you have the official 2024 PDF, the logo SVG, the licensed fonts, or a UI codebase to onboard — drop them in and the system will tighten further.

---

Last updated: **2026-04-26** — consolidated from the [Design System Review](../_review/Design_System_Review_2026-04-26.html) (all 18 findings addressed). Next review due 2026-07-26.
