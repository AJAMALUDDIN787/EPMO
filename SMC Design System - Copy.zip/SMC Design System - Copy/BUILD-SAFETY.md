# SMC Design System — Build Safety Contract

> **This is a hard contract.** Every PPTX built off this Design System MUST satisfy these rules. No exceptions.
> Source-of-truth: [`tokens/smc-brand.yaml`](tokens/smc-brand.yaml) §20 `pptx_safety` · helpers in [`lib/safe-helpers.js`](lib/safe-helpers.js).

---

## Why this file exists

The April 2026 HRH-of-MoS deck shipped **corrupted** because a width-arithmetic bug produced a negative `cx` on a text box. The error mode was silent at every level — `python-pptx` parsed the file, `Spire` rendered it to PDF, the build script reported success — but PowerPoint refused to open the file.

The 2026-04-22 gaming stress test passed structural validation but the user caught **three layout bugs on visual inspection**: text overflow on slide 3, off-canvas shapes on slides 4/7, non-scaling text on slide 8.

The institutional memory of every PPTX bug since 2026-Q1 lives in `pptx-lessons` (skill). This file mirrors it into the Design System so any builder reading the brand contract sees the engineering contract too.

---

## The mandatory pipeline

Every build of an SMC PPTX deck — whether by `pptxgenjs`, `python-pptx`, or the Anthropic `pptx` skill — runs:

```
   1. Source build script
       │
       │  (uses lib/safe-helpers.js wrappers — pre-emit clamps)
       ▼
   2. pptx_fix.py                         <-- mandatory post-build
       (.claude/skills/pptx-repair/)
       Patches: B01 phantom CT · B02 zero-dim ·
                B04b negative-dim · B03 rightTriangle
       │
       ▼
   3. lint_layout.py                      <-- mandatory layout check
       (.claude/skills/pptx-repair/)
       Catches: B09 overflow · B10 off-canvas ·
                B11 chrome-zone · B12 overlap · B13 scaling
       Block on: L1 (off-canvas) · L2 (chrome-zone)
       │
       ▼
   4. Render verification (multi-probe)
       Probe A: python-pptx structural parse  (REQUIRED)
       Probe B: PowerPoint COM SaveAs PDF     (REQUIRED if Windows)
       Probe C: LibreOffice headless          (fallback)
       Probe D: Spire (last resort, page-count guarded)
       │
       ▼
   5. markitdown content-fidelity diff
       (output items per slide vs source spec)
       │
       ▼
   ✓  SHIP
```

**A single failure at any step blocks ship.** The team-old practice of "ship anyway, the structural test passed" produced two corrupted Minister-level decks. Don't repeat it.

---

## Bug catalog — what each rule prevents

| ID | Bug | Symptom | Required helper |
|---|---|---|---|
| **B01** | Phantom `[Content_Types].xml` Override entries | PowerPoint "file is corrupted" on open; pptxgenjs declares slideMaster2–10 without writing them | `pptx_fix.py` strips them post-build |
| **B02** | Zero-dimension shapes (`pres.shapes.LINE` with `w:0` / `h:0`) | OOXML `<a:ext cx="0"/>` — PowerPoint rejects on `<p:sp>` | **NEVER use `pres.shapes.LINE`.** Use `hRule()` / `vRule()` (thin positive-dim RECTANGLE) |
| **B03** | Invalid `rightTriangle` preset | OOXML spec is `triangle` — PowerPoint refuses | Post-build XML patch · or use `triangle` from the start |
| **B04** | Negative line dimensions (`w<0` or `h<0` on lines) | PowerPoint refuses to open | Normalize endpoints with `Math.min/Math.max`; emit positive dims + `flipV/flipH` |
| **B04b** | Negative text-box width (formula bug — bug-007) | "PowerPoint could not open the file" — bug-007 broke the HRH deck | **Every computed `w`/`h` MUST pass through `safeW()`/`safeH()`.** |
| **B05** | `rotate:N` on `triangle` / `rightTriangle` preset | PowerPoint refuses | Use `flipV`/`flipH` instead, or pick a preset with the correct default orientation |
| **B06** | Unicode escape trap in Edit tool | Non-ASCII char written where source needs literal `\uXXXX` escape | Double-escape (`\\uXXXX`) in Edit args; verify with `wc -l` + `tail`, not Read |
| **B07** | `pptx_fix.py` Unicode crash on Windows cp1252 | Print of `→` exits with code 1 (fix succeeded but reported failure) | **FIXED** — script now reconfigures stdout to UTF-8 |
| **B08** | Spire free-tier truncation past ~3 slides + nag page | Old QA returned false PASS on 10-slide decks | Use multi-probe `render-check.md` — Spire is last resort, page-count-guarded |
| **B09** | Text overflows its bounding box (FS × LSM × lines > h × 72) | Hero metrics bleed into adjacent content; structural tests miss it | **Every `addText` MUST use `safeFont(wanted, h, lines)`.** |
| **B10** | Shape positioned off-canvas | Content clipped at slide edge in PDF exports; python-pptx + Spire pass it | **Every `addShape`/`addText` MUST use `safeBounds(x, y, w, h)`.** |
| **B11** | Content intrudes into header / footer chrome zones | Title clips into gold top bar · KPI cards bleed into footer dune band | **Every non-chrome shape MUST satisfy `inSafeZone(x, y, w, h)`** — read `safe_zones` from YAML at build time |
| **B12** | Unintentional opaque-on-opaque shape overlap | Visually muddled hierarchy | Overlap allowed ONLY when: transparent · text-over-fill · declared composite primitive |
| **B13** | Non-scaling text in scaling container (funnels, shrinking bars) | Text overflows narrow stages | **Every variable-width container MUST use `scaledFont(base, currentW, maxW)`** |

---

## Required helpers (drop-in)

All helpers live in [`lib/safe-helpers.js`](lib/safe-helpers.js). Every build script must import and use them.

### `safeW(w)` / `safeH(h)` — never-negative width/height clamps
```js
const safeW = (w) => Math.max(0.10, w);   // 0.10″ minimum (~7 pt)
const safeH = (h) => Math.max(0.10, h);
```
**Use:** every computed width or height in an `addShape` / `addText` call. Catches bug-007.

### `safeFont(wanted, box_h_in, lines, lh)` — never-overflow font cap
```js
function safeFont(wanted, box_h_in, lines = 1, lh = 1.2) {
  const max_pt = Math.floor((box_h_in * 72 * 0.9) / (lines * lh));
  return Math.min(wanted, max_pt);
}
```
**Use:** every `fontSize` in an `addText` call. Catches B09.

### `safeBounds(x, y, w, h)` — fail-fast off-canvas guard
```js
function safeBounds(x, y, w, h, canvas = { W: 13.333, H: 7.5 }) {
  const issues = [];
  if (x < 0) issues.push(`x<0 (${x.toFixed(2)})`);
  if (y < 0) issues.push(`y<0 (${y.toFixed(2)})`);
  if (x + w > canvas.W) issues.push(`x+w>W (${(x+w).toFixed(2)} > ${canvas.W})`);
  if (y + h > canvas.H) issues.push(`y+h>H (${(y+h).toFixed(2)} > ${canvas.H})`);
  if (issues.length) throw new Error(`OFF-CANVAS: ${issues.join(', ')}`);
  return { x, y, w, h };
}
```
**Use:** every `addShape` / `addText`. Catches B10.

### `inSafeZone(x, y, w, h, zone)` — chrome-zone guard
```js
function inSafeZone(x, y, w, h, zone) {
  return y >= zone.top_safe_y
      && y + h <= zone.bottom_safe_y
      && x >= zone.left_safe_x
      && x + w <= zone.right_safe_x;
}
```
**Use:** every non-chrome shape. Reads `safe_zones` from `tokens/smc-brand.yaml`. Catches B11.

### `scaledFont(base, currentW, maxW, minReadable)` — proportional font scaling
```js
function scaledFont(base, currentW, maxW, minReadable = 9) {
  const scaled = Math.round(base * (currentW / maxW));
  return Math.max(minReadable, Math.min(base, scaled));
}
```
**Use:** funnels, shrinking bars, bento cells with varied widths. Catches B13.

### `hRule(slide, x, y, w, color, thick)` / `vRule(slide, x, y, h, color, thick)` — line replacements
```js
function hRule(s, x, y, w, color, thick = 0.015) {
  if (w <= 0) return;
  s.addShape(pres.shapes.RECTANGLE, {
    x, y: y - thick / 2, w, h: thick,
    fill: { color }, line: { color }
  });
}
```
**Use:** any horizontal/vertical rule. **Never use `pres.shapes.LINE`.** Catches B02.

### `tableShapeGrid(slide, opts)` — the canonical table renderer
See `lib/safe-helpers.js#tableShapeGrid()`. Every SMC table MUST use this pattern (see [`tokens/smc-brand.yaml`](tokens/smc-brand.yaml) §12 for the rule of thumb).

---

## What the rules prevent — one-line summaries

- **B01–B05** (file-format) = "PowerPoint won't even open the deck."
- **B07–B08** (build-tool) = "False PASS in CI, broken file ships."
- **B09** = "Hero metrics overflow into the title above."
- **B10** = "Bottom hub-spoke labels are clipped at the slide edge in the PDF."
- **B11** = "KPI card sits ON TOP of the footer dune band."
- **B12** = "Two opaque cards overlap; reader can't tell what's primary."
- **B13** = "Funnel stage 5 text is bigger than the bar it sits in."

If you can't answer "which helper prevents this" for a build path, that build path is unsafe. Stop and add the helper.

---

## When to refresh this file

- New bug discovered → add row to catalog · update `pptx-lessons` skill · update `tokens/smc-brand.yaml` §20.
- New helper introduced → add section above · publish in `lib/safe-helpers.js` · update §9 in YAML.
- Pipeline step changed → update the diagram and the `pptx_safety` block in YAML.

Last updated: 2026-04-26 (Design System review consolidation — Moe approved C-02).
