# SMC Design System — File Naming & Output Convention

> Single rule: **every deliverable filename tells you the date, the topic, the language, the classification, and the version — at a glance.**
> Source-of-truth: [`tokens/smc-brand.yaml`](tokens/smc-brand.yaml) §19 `naming`.

---

## The pattern

```
YYYY-MM-DD-<slug>-<lang>-<classification>-v<F>.<ext>
```

| Part | What | Example |
|---|---|---|
| `YYYY-MM-DD` | ISO date — start date for engagements, finalise date for deliverables | `2026-04-26` |
| `<slug>` | Kebab-case topic (no spaces, no underscores) | `EPMO-EMO-Harmony` |
| `<lang>` | `EN` · `AR` · `EN-AR` (bilingual) | `EN-AR` |
| `<classification>` | `Internal` · `Confidential` · `Board` · `Public` | `Confidential` |
| `v<F>` | Single-digit (or decimal) version | `v3` · `v3.1` |
| `<ext>` | `pptx` · `docx` · `xlsx` · `pdf` · `html` | `pptx` |

---

## Examples

| Deliverable | Filename |
|---|---|
| EPMO–EMO Harmony deck for internal review | `2026-04-26-EPMO-EMO-Harmony-EN-Internal-v3.pptx` |
| Risk Management Policy bilingual document | `2026-04-26-Risk-Policy-EN-AR-Confidential-v5.docx` |
| Board pack for May meeting | `2026-05-12-Board-Pack-EN-Board-v1.pptx` |
| Annual report for public release | `2026-12-31-Annual-Report-EN-AR-Public-v2.pdf` |
| HRH MoS executive briefing | `2026-04-15-HRH-MoS-Briefing-EN-AR-Confidential-v3.pptx` |
| Sponsorship proposal for Aramco | `2026-06-01-Aramco-Sponsorship-EN-Confidential-v1.pptx` |

---

## Archive convention

When a deliverable is finalised and archived, suffix `-FINAL` to the version part and move it to the archive folder.

```
YYYY-MM-DD-<slug>-vF-FINAL.<ext>
```

**Archive folder pattern:**
```
<area>/_transient/_archive/YYYY-MM — <name>/
```

**Example:**
```
SMC Transformation/_transient/_archive/2026-04 — EPMO-EMO Harmony/
    2026-04-26-EPMO-EMO-Harmony-EN-Internal-v3-FINAL.pptx
    2026-04-26-EPMO-EMO-Harmony-EN-Internal-v3-FINAL.pdf
    PROJECT_SUMMARY.md     ← points to vault [[note]]
```

---

## Classification ladder

| Classification | Audience | Footer text | Distribution |
|---|---|---|---|
| `Internal` | SMC employees | `Confidential — Internal Use` | SharePoint, internal email |
| `Confidential` | Named recipient list | `Confidential — Restricted` | Encrypted email, secure share |
| `Board` | Board members + invited execs | `Board Distribution — Confidential` | Board portal only |
| `Public` | Anyone | `SMC · 2026` | Website, public PR |

---

## Don't

- Don't use spaces in filenames. Use hyphens.
- Don't put underscores in the slug. Use hyphens.
- Don't omit the date — it's the primary sort key.
- Don't skip the language tag — bilingual is too common to leave ambiguous.
- Don't leave `v?` or `vDRAFT` in a final deliverable. Use `v1`, `v2`, … and `-FINAL` at archive.
- Don't reuse a version number after archive. If you reopen the work, increment.
- Don't put the classification in the filename body — keep it in the structured slot.
- Don't use British vs American spelling inconsistently in slugs (pick one — `Programme` for SMC).

---

## Why this matters

A 50+ policy sprint, an 18-month strategy programme, and a quarterly board cycle all create dozens of files per month. Without a discipline, those files become unsearchable in 6 months and unattributable in 12. The convention above fixes the order of metadata so any tool's filename sort surfaces the right document instantly.

Last updated: 2026-04-26.
