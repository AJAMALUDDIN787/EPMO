---
name: smc-design
description: Use this skill to generate well-branded interfaces and assets for Saudi Motorsport Company (SMC). Covers slide decks, mocks, prototypes, dashboards, reports, charters, policies, signed documents, and any artefact where SMC's design contract applies. Includes brand tokens, slide-type library, build-safety helpers, table-as-shapes pattern, bilingual EN↔AR support, Portrait A4 templates (v6.1), and Minister-grade ministerial/royal tier (v6.2).
user-invocable: true
---

Read `README.md` first, then explore as needed:

- **`tokens/smc-brand.yaml`** — single source of truth. Read this for any value-level question (color hex, type pt, safe-zone bounds, table grid spec, sub-brand routing, Minister-grade overrides).
- **`MINISTER-GRADE-CHECKLIST.md`** — **MANDATORY** when audience tier = Minister (HRH / Royal / ministerial). Pre-flight + mid-flight + post-flight checks. Codified from the HRH-approved JCC Land Options deck (2026-04-29).
- **`BUILD-SAFETY.md`** — mandatory PPTX engineering contract (B01–B13 bug catalog, required helpers, post-build pipeline). Read before building any `.pptx`.
- **`NAMING.md`** — file naming convention for SMC deliverables.
- **`colors_and_type.css`** — drop-in for HTML mockups.
- **`lib/safe-helpers.js`** — `safeW`, `safeH`, `safeFont`, `safeBounds`, `inSafeZone`, `scaledFont`, `hRule`, `vRule`, `tableShapeGrid`, `guard`.
- **`lib/coordinate-bridge.js`** — px ↔ pt ↔ in ↔ EMU conversion.
- **`preview/index.html`** — preview hub (23 pages).
- **`slides/index.html`** — slide template hub (13 templates).

## Quick reference

- **Primary colors (locked):** Dark Teal `#00625B`, Forest Green `#009667`
- **Supporting:** Gold `#C59A3C` (accent only — never body), Asphalt `#141414`, Off-White `#FAFAF8`, Dune `#EDE7DB`
- **60 · 30 · 10 proportion** — Teal 60% · Off-White 20% · Asphalt 12% · Dune 5% · Gold 3%
- **Fonts:** Century Gothic (EN), Sakkal Majalla (AR · +15%). Fallbacks Jost and Cairo.
- **Safe zones:** top 0.95″ · bottom 6.97″ · left 0.40″ · right 12.93″ — title block lives INSIDE the upper safe zone.
- **Title-frame patterns:** hairline (default) or band (Dune-toned) — both fill the upper safe zone.
- **Voice:** decisive · precise · authoritative · purposeful. Institutional register. Slide titles carry the message — never label.
- **No** drop shadows · glows · emoji · rounded web cards · decorative underlines · copper · electric lime in corporate.
- **Subtle gradients** allowed in 4 named locations only (gold-button hover · Premium Gold callout asphalt panel · cover diagonal-line texture · photo protection scrim). Never on body cards, KPI blocks, footer, default buttons.
- **Tables** are a GRID OF SHAPES — `lib/safe-helpers.js#tableShapeGrid()`. Never `pptxgenjs.addTable` for layout-precise work.
- **Bilingual** (Government / Board) — slides 09 (content split), 10 (cover), 11 (exec brief). Arabic uses `Sakkal Majalla` at 1.15× English size.
- **Portrait A4** (reports · charters · policies · signed docs) — `slides/portrait/` (6 templates: cover · summary · gantt · stakeholders · org-standard · org-wide). PowerPoint setup: Slide Size → A4 Paper (210 × 297 mm) Portrait. Tokens at `tokens/smc-brand.yaml` §22. Outer margin 0.75″. Title zone fixed 1.40″ (no bleed). 3-col GANTT always. Far-left riser for org with ≥4 leads.

## Loading the system in HTML

```html
<link rel="stylesheet" href="colors_and_type.css">
```

Then use `var(--smc-dark-teal)`, `.smc-eyebrow`, `.smc-bullet`, `.smc-display`, `.smc-hero-l`, `.smc-kpi`, `.smc-ar`, etc.

## Sub-brands (footer-routing)

| Sub-brand | Footer left | Dominant | Use |
|---|---|---|---|
| EPMO | `SMC · EPMO` | Teal | Internal portfolio · governance |
| EMO | `SMC · EMO` | Teal + Green | Event ops · cross-team |
| Live Event | `SMC · Live Event` | Green + Teal | Race · fan-facing |
| Hospitality | `SMC · Hospitality` | Dune + Teal | Guest experience · VIP |
| Corporate | `SMC · Corporate` | Teal | Comms · investor · annual |
| Government | `SMC · Government Liaison` | Teal + Asphalt · bilingual | Ministerial · royal · stakeholder |

## Build safety (non-negotiable for `.pptx`)

```
build script (uses safe-helpers wrappers)
   ↓
.claude/skills/pptx-repair/pptx_fix.py        ← post-build (B01·B02·B03·B04b)
   ↓
.claude/skills/pptx-repair/lint_layout.py     ← layout lint (B09·B10·B11·B12·B13)
   ↓ block on L1 (off-canvas) / L2 (chrome-zone)
multi-probe render check (python-pptx · PPT COM · LibreOffice · Spire)
   ↓
markitdown content-fidelity diff
   ↓ ✓ ship
```

See `BUILD-SAFETY.md` for full bug catalog and helper signatures.

## Minister-grade tier (v6.2 · 2026-05-01)

When audience is HRH, Royal Family, Minister of Sport, or equivalent ministerial seat — load `MINISTER-GRADE-CHECKLIST.md` BEFORE building. The Government sub-brand has **two tiers**:

- **Stakeholder** (default): bilingual EN+AR, "SMC · Government Liaison" footer, generic decision close
- **Minister**: Arabic end-to-end, full Arabic SMC name in footer, mandatory `minister_decision_ask` slide ("توجيه سموكم الكريم"), mandatory `minister_thank_you` slide ("شكرا لسموكم"), `appendix_wrapper` for source decks. Headline color `teal_ink #002E2B`. Every headline a full executive sentence. NO audience mention on cover.

Reference visuals at `assets/minister-grade/`. Token contract at `tokens/smc-brand.yaml` §13b.

## When invoked without guidance

Ask Moe: "What are you building — a deck (which sub-brand? if Government, stakeholder or Minister tier?), a single slide, a dashboard, a mock, or something else?" Then route to the right tier and slide types from `tokens/smc-brand.yaml` §10. For Minister tier, also load `MINISTER-GRADE-CHECKLIST.md`.

## Arabic baseline — Layer A

For Arabic copy at any tier, load `~/.claude/skills/arabic-style/` (Layer A) **before** applying this skill's overrides. The arabic-style hub provides the five-tier audience framework, EN→AR translation moves, MSA grammar / char-ratio sanity gate, and the classification gate for routing Moe's corrections. This skill (Layer B) overlays it — Minister-grade overrides (royal honorifics, decision-ask `توجيه` pattern, opt-out clause, Arabic-end-to-end chrome) on top of the baseline. Brand YAML `tokens/smc-brand.yaml#identity.name_ar` (Layer C) wins for the SMC name. Rendering rules (Sakkal Majalla, +15% sizing, RTL bidi) stay in the rendering skill (Layer D), not in arabic-style.
