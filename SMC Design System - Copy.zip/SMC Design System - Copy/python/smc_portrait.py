"""
smc_portrait.py — canonical builder for A4 portrait PowerPoint documents.

This is the locked-in look-and-feel for any portrait deliverable that follows
the SMC Design System (v6.1+). Brand colors, fonts, and content are passed in
as parameters; the LAYOUT (margins, title positioning, signature framing,
table styling, etc.) is enforced here.

Use it whenever portrait PowerPoint output is requested — engagement charters,
portrait one-pagers, signed authorizations, A4 reports with a print/sign step.

Locked rules (do not edit without updating tokens/smc-brand.yaml v6.1+):
  • Canvas             A4 portrait (8.27 × 11.69 in)
  • Page background    pure white #FFFFFF (print/sign/archive)
  • Outer LR margin    0.60 in (trimmed from 0.75 in on 2026-04-27)
  • Gold top bar       0.06 in (full-bleed)
  • Footer band        0.50 in (dune, with gold accent line above)
  • Title zone         eyebrow @ y=0.26 · h1 @ y=0.46 · lede @ y=1.10 · hairline @ y=1.90
  • Body zone          y=1.95 → y=9.40 (auth/sign pages may extend to y≈11.09)
  • Tables             native PPT tables (NOT shape grids) — Moe rule 2026-04-26
  • Signatures         min 1.50 in tall · ≥0.55 in clear above signature line
  • Body bullets       use SHAPE_TO_FIT_TEXT autofit so wrap never clips silently
  • Tricolon ban       no "One X. One Y. One Z." headlines (memory rule)

Brand-agnostic — the default palette is SMC. Pass a custom Palette instance
to use any other brand (MoX, ministry brand, partner brand, etc.).

Origin: build_charter.py from .planning/_transient/2026-04-26-ip-charter-options
2026-04-27 — extracted, generalized, locked.
"""
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR, MSO_AUTO_SIZE
from lxml import etree

# ═══════════════════════════════════════════════════════════════════════════
# CANVAS & ZONE CONSTANTS — locked v6.1+ (2026-04-27 trim)
# ═══════════════════════════════════════════════════════════════════════════
SLIDE_W = Inches(8.27)         # 210 mm
SLIDE_H = Inches(11.69)        # 297 mm

OUTER_LR        = Inches(0.60) # was 0.75 in v6.1; trimmed 2026-04-27
TITLE_TOP       = Inches(0.50)
TITLE_HEIGHT    = Inches(1.40)
BODY_TOP        = Inches(1.95)
BODY_BOTTOM     = Inches(9.40)
FOOTER_TOP      = Inches(11.19)
FOOTER_HEIGHT   = Inches(0.50)
TOPBAR_HEIGHT   = Inches(0.06)

# Title content positions (locked 2026-04-26 — eyebrow lifted from mid-zone to top)
EYEBROW_Y       = Inches(0.26)
H1_Y            = Inches(0.46)
LEDE_Y          = Inches(1.10)
HAIRLINE_Y      = BODY_TOP - Emu(6350)   # ~y=1.93

BODY_W          = SLIDE_W - 2 * OUTER_LR  # 7.07 in
BODY_H          = BODY_BOTTOM - BODY_TOP  # 7.45 in

# Common font sizing
SIZE_EYEBROW    = 8.5
SIZE_H1         = 20
SIZE_LEDE       = 10
SIZE_BODY       = 9.5
SIZE_FIELD_KEY  = 7.5
SIZE_FIELD_VAL  = 10
SIZE_TABLE_BODY = 9.5
SIZE_TABLE_HEAD = 8
SIZE_FOOT       = 8

LETTER_SPACING_EYEBROW = 200  # hundredths of a point
LETTER_SPACING_LABEL   = 180

# Fonts — overridable per brand (Cairo for Arabic projects, etc.)
FONT_DISPLAY = "Century Gothic"
FONT_MONO    = "Consolas"


# ═══════════════════════════════════════════════════════════════════════════
# PALETTE — brand-agnostic. Override by subclassing or instancing.
# ═══════════════════════════════════════════════════════════════════════════
class Palette:
    """Default = SMC v6.1. Override by instancing or subclassing.
    Example for a custom brand:
        class MoXPalette(Palette):
            primary = RGBColor(0xFF, 0x80, 0x40)
            accent  = RGBColor(0xE0, 0xE0, 0xE0)
        # then pass the class (or an instance) to component builders
    """
    primary       = RGBColor(0x00, 0x62, 0x5B)
    primary_deep  = RGBColor(0x00, 0x49, 0x43)
    primary_tint  = RGBColor(0xE6, 0xEF, 0xEE)
    accent        = RGBColor(0xC5, 0x9A, 0x3C)
    accent_tint   = RGBColor(0xF7, 0xEF, 0xD9)
    asphalt       = RGBColor(0x14, 0x14, 0x14)
    asphalt_soft  = RGBColor(0x2A, 0x2D, 0x30)
    muted         = RGBColor(0x6B, 0x75, 0x70)
    faint         = RGBColor(0x9B, 0xA3, 0x9E)
    hairline      = RGBColor(0xE5, 0xE7, 0xEB)
    page_bg       = RGBColor(0xFF, 0xFF, 0xFF)
    white         = RGBColor(0xFF, 0xFF, 0xFF)
    band_bg       = RGBColor(0xED, 0xE7, 0xDB)
    band_dk       = RGBColor(0xD9, 0xD0, 0xBE)
    danger        = RGBColor(0x8A, 0x30, 0x30)
    danger_bg     = RGBColor(0xFB, 0xF1, 0xEE)
    success       = RGBColor(0x00, 0x96, 0x67)
    success_tint  = RGBColor(0xE5, 0xF4, 0xEC)


# ═══════════════════════════════════════════════════════════════════════════
# SHAPE PRIMITIVES
# ═══════════════════════════════════════════════════════════════════════════
def kill_shadow(shape):
    """Strip inherited theme shadows. Design system rule: hairlines + color blocks only."""
    sppr = shape._element.spPr
    A = 'http://schemas.openxmlformats.org/drawingml/2006/main'
    existing = sppr.find(f'{{{A}}}effectLst')
    if existing is not None:
        sppr.remove(existing)
    etree.SubElement(sppr, f'{{{A}}}effectLst')
    return shape


def add_rect(slide, x, y, w, h, fill=None, line_color=None, line_width=None):
    shp = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, x, y, w, h)
    shp.shadow.inherit = False
    if fill is None:
        shp.fill.background()
    else:
        shp.fill.solid()
        shp.fill.fore_color.rgb = fill
    if line_color is None:
        shp.line.fill.background()
    else:
        shp.line.color.rgb = line_color
        if line_width is not None:
            shp.line.width = line_width
    kill_shadow(shp)
    return shp


def add_line(slide, x1, y1, x2, y2, color, width=Pt(0.5)):
    """Hairline as a narrow rectangle (more reliable than connectors)."""
    if y1 == y2:
        h = max(width, Emu(3175))
        shp = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, x1, y1, x2 - x1, h)
    else:
        w = max(width, Emu(3175))
        shp = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, x1, y1, w, y2 - y1)
    shp.shadow.inherit = False
    shp.fill.solid()
    shp.fill.fore_color.rgb = color
    shp.line.fill.background()
    kill_shadow(shp)
    return shp


def add_text(slide, x, y, w, h, text, *, size=10, font=FONT_DISPLAY, color=None,
             bold=False, italic=False, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP,
             letter_spacing=None, line_spacing=1.15, margin=Pt(2),
             autofit=False, palette=Palette):
    if color is None:
        color = palette.asphalt
    box = slide.shapes.add_textbox(x, y, w, h)
    tf = box.text_frame
    tf.margin_left = margin
    tf.margin_right = margin
    tf.margin_top = Pt(1)
    tf.margin_bottom = Pt(1)
    tf.word_wrap = True
    tf.auto_size = MSO_AUTO_SIZE.SHAPE_TO_FIT_TEXT if autofit else MSO_AUTO_SIZE.NONE
    tf.vertical_anchor = anchor
    p = tf.paragraphs[0]
    p.alignment = align
    p.line_spacing = line_spacing
    run = p.add_run()
    run.text = text
    run.font.name = font
    run.font.size = Pt(size)
    run.font.color.rgb = color
    run.font.bold = bold
    run.font.italic = italic
    if letter_spacing is not None:
        rPr = run._r.get_or_add_rPr()
        rPr.set('spc', str(letter_spacing))
    return box


def add_text_multi(slide, x, y, w, h, runs, *, align=PP_ALIGN.LEFT,
                   anchor=MSO_ANCHOR.TOP, line_spacing=1.2, margin=Pt(2),
                   autofit=False, palette=Palette):
    """runs = list of (text, opts) where opts may include
    {size, color, bold, italic, font, spc, newline_before}"""
    box = slide.shapes.add_textbox(x, y, w, h)
    tf = box.text_frame
    tf.margin_left = margin
    tf.margin_right = margin
    tf.margin_top = Pt(1)
    tf.margin_bottom = Pt(1)
    tf.word_wrap = True
    tf.auto_size = MSO_AUTO_SIZE.SHAPE_TO_FIT_TEXT if autofit else MSO_AUTO_SIZE.NONE
    tf.vertical_anchor = anchor
    p = tf.paragraphs[0]
    p.alignment = align
    p.line_spacing = line_spacing
    first = True
    for text, opts in runs:
        if opts.get('newline_before') and not first:
            p = tf.add_paragraph()
            p.alignment = align
            p.line_spacing = line_spacing
            text = text.lstrip('\n')
        first = False
        r = p.add_run()
        r.text = text
        r.font.name = opts.get('font', FONT_DISPLAY)
        r.font.size = Pt(opts.get('size', 10))
        r.font.color.rgb = opts.get('color', palette.asphalt)
        r.font.bold = opts.get('bold', False)
        r.font.italic = opts.get('italic', False)
        if 'spc' in opts:
            rPr = r._r.get_or_add_rPr()
            rPr.set('spc', str(opts['spc']))
    return box


# ═══════════════════════════════════════════════════════════════════════════
# CHROME — gold top bar, dune footer band, page-info text
# ═══════════════════════════════════════════════════════════════════════════
def add_chrome(slide, page_label, page_num_text, palette=Palette):
    add_rect(slide, 0, 0, SLIDE_W, TOPBAR_HEIGHT, fill=palette.accent)
    add_rect(slide, 0, FOOTER_TOP, SLIDE_W, FOOTER_HEIGHT, fill=palette.band_bg)
    add_rect(slide, 0, FOOTER_TOP - Emu(19050), SLIDE_W, Emu(19050), fill=palette.accent)
    foot_left_w  = Inches(4.50)   # was 4.30 — wider page allows longer left text
    foot_right_w = Inches(2.30)
    add_text(slide, OUTER_LR, FOOTER_TOP + Inches(0.18), foot_left_w, Inches(0.20),
             page_label, size=SIZE_FOOT, color=palette.muted, bold=True,
             letter_spacing=LETTER_SPACING_EYEBROW, anchor=MSO_ANCHOR.MIDDLE)
    add_text(slide, SLIDE_W - OUTER_LR - foot_right_w, FOOTER_TOP + Inches(0.18),
             foot_right_w, Inches(0.20), page_num_text,
             size=SIZE_FOOT, color=palette.muted, bold=True,
             letter_spacing=LETTER_SPACING_EYEBROW, align=PP_ALIGN.RIGHT,
             anchor=MSO_ANCHOR.MIDDLE)


# ═══════════════════════════════════════════════════════════════════════════
# TITLE BLOCKS — hairline (default) and dune-band (cover) variants
# ═══════════════════════════════════════════════════════════════════════════
def add_title(slide, eyebrow, h1, lede=None, meta_r=None, palette=Palette):
    """Standard hairline title. Eyebrow lifted to y=0.26 per 2026-04-26 rule.
    H1 should be a formal section name (NOT marketing copy). Charter-grade:
        good: 'Project Organization.'
        bad:  'Who works on this · charged to this engagement.'
    """
    x = OUTER_LR
    w = BODY_W
    add_text(slide, x, EYEBROW_Y, w - Inches(2.2), Inches(0.18),
             eyebrow.upper(), size=SIZE_EYEBROW, color=palette.primary, bold=True,
             letter_spacing=LETTER_SPACING_EYEBROW, anchor=MSO_ANCHOR.TOP,
             palette=palette)
    add_text(slide, x, H1_Y, w, Inches(0.62),
             h1, size=SIZE_H1, color=palette.asphalt, bold=True,
             line_spacing=1.10, palette=palette)
    if lede:
        add_text(slide, x, LEDE_Y, w, Inches(0.50),
                 lede, size=SIZE_LEDE, color=palette.muted, line_spacing=1.45,
                 palette=palette)
    if meta_r:
        add_text(slide, SLIDE_W - OUTER_LR - Inches(2.0), EYEBROW_Y,
                 Inches(2.0), Inches(0.18),
                 meta_r.upper(), size=SIZE_FOOT, color=palette.muted, bold=True,
                 letter_spacing=LETTER_SPACING_LABEL, align=PP_ALIGN.RIGHT,
                 anchor=MSO_ANCHOR.TOP, palette=palette)
    add_line(slide, x, HAIRLINE_Y, x + w, HAIRLINE_Y,
             color=palette.hairline, width=Pt(0.5))


def add_title_band(slide, eyebrow, h1, palette=Palette, band_h=Inches(1.20)):
    """Full-bleed dune band title (used on cover slides).
    Band height defaults to 1.20 in to safely contain a 2-line H1 wrap."""
    band_top = TOPBAR_HEIGHT
    add_rect(slide, 0, band_top, SLIDE_W, band_h, fill=palette.band_bg)
    add_rect(slide, 0, band_top + band_h, SLIDE_W, Emu(9525), fill=palette.band_dk)
    add_text(slide, OUTER_LR, band_top + Inches(0.18), BODY_W, Inches(0.18),
             eyebrow.upper(), size=SIZE_EYEBROW, color=palette.primary, bold=True,
             letter_spacing=LETTER_SPACING_EYEBROW, palette=palette)
    add_text(slide, OUTER_LR, band_top + Inches(0.40), BODY_W, Inches(0.74),
             h1, size=17, color=palette.asphalt, bold=True, line_spacing=1.10,
             palette=palette)


# ═══════════════════════════════════════════════════════════════════════════
# SECTION LABEL (eyebrow style) — for body sections
# ═══════════════════════════════════════════════════════════════════════════
def lbl(slide, x, y, w, text, *, color=None, suffix=None, suffix_offset_in=2.7,
        palette=Palette):
    if color is None:
        color = palette.primary
    if suffix:
        label_w = Inches(suffix_offset_in - 0.05)
        add_text(slide, x, y, label_w, Inches(0.18), text.upper(),
                 size=SIZE_EYEBROW, color=color, bold=True,
                 letter_spacing=LETTER_SPACING_EYEBROW, palette=palette)
        add_text(slide, x + Inches(suffix_offset_in), y,
                 w - Inches(suffix_offset_in), Inches(0.18),
                 suffix, size=SIZE_EYEBROW, color=palette.muted, palette=palette)
    else:
        add_text(slide, x, y, w, Inches(0.18), text.upper(),
                 size=SIZE_EYEBROW, color=color, bold=True,
                 letter_spacing=LETTER_SPACING_EYEBROW, palette=palette)


# ═══════════════════════════════════════════════════════════════════════════
# TILE / BULLET-TILE — generic body containers
# ═══════════════════════════════════════════════════════════════════════════
def tile(slide, x, y, w, h, *, title=None, title_color=None, accent_left=None,
         body_runs=None, body_text=None, fill=None, border=None, palette=Palette):
    """Outline rectangle + optional left-accent stripe + title + body.
    Body uses SHAPE_TO_FIT_TEXT so wrapping never clips silently — but you
    must still size h generously so the rectangle visually contains the text.
    If text grows beyond rect, that's a signal to enlarge h on next iteration.
    """
    if title_color is None:
        title_color = palette.primary
    if fill is None:
        fill = palette.white
    if border is None:
        border = palette.hairline
    add_rect(slide, x, y, w, h, fill=fill, line_color=border, line_width=Pt(0.5))
    if accent_left is not None:
        add_rect(slide, x, y, Emu(28575), h, fill=accent_left)
    inner_x = x + Inches(0.13)
    inner_w = w - Inches(0.26)
    inner_y = y + Inches(0.10)
    if title:
        add_text(slide, inner_x, inner_y, inner_w, Inches(0.18),
                 title.upper(), size=SIZE_FOOT, color=title_color, bold=True,
                 letter_spacing=LETTER_SPACING_EYEBROW, palette=palette)
        inner_y = inner_y + Inches(0.22)
    body_h = h - (inner_y - y) - Inches(0.10)
    if body_runs:
        add_text_multi(slide, inner_x, inner_y, inner_w, body_h,
                       body_runs, line_spacing=1.40, autofit=True, palette=palette)
    elif body_text:
        add_text(slide, inner_x, inner_y, inner_w, body_h,
                 body_text, size=SIZE_BODY, color=palette.asphalt,
                 line_spacing=1.45, autofit=True, palette=palette)


def bullet_tile(slide, x, y, w, h, *, title=None, title_color=None,
                accent_left=None, items, fill=None, border=None,
                bullet_size=SIZE_BODY, palette=Palette):
    """Tile with bullet items prefixed by '→ '."""
    if title_color is None: title_color = palette.primary
    if fill is None: fill = palette.white
    if border is None: border = palette.hairline
    add_rect(slide, x, y, w, h, fill=fill, line_color=border, line_width=Pt(0.5))
    if accent_left is not None:
        add_rect(slide, x, y, Emu(28575), h, fill=accent_left)
    inner_x = x + Inches(0.13)
    inner_w = w - Inches(0.26)
    inner_y = y + Inches(0.10)
    if title:
        add_text(slide, inner_x, inner_y, inner_w, Inches(0.18),
                 title.upper(), size=SIZE_FOOT, color=title_color, bold=True,
                 letter_spacing=LETTER_SPACING_EYEBROW, palette=palette)
        inner_y = inner_y + Inches(0.22)
    box = slide.shapes.add_textbox(inner_x, inner_y, inner_w,
                                    h - (inner_y - y) - Inches(0.08))
    tf = box.text_frame
    tf.margin_left = Pt(2); tf.margin_right = Pt(2)
    tf.margin_top = Pt(0); tf.margin_bottom = Pt(0)
    tf.word_wrap = True
    tf.auto_size = MSO_AUTO_SIZE.SHAPE_TO_FIT_TEXT
    for i, item in enumerate(items):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = PP_ALIGN.LEFT
        p.line_spacing = 1.30
        if i > 0: p.space_before = Pt(2)
        r = p.add_run()
        r.text = "→ " + item
        r.font.name = FONT_DISPLAY
        r.font.size = Pt(bullet_size)
        r.font.color.rgb = palette.asphalt


# ═══════════════════════════════════════════════════════════════════════════
# NATIVE PPT TABLE — Moe rule 2026-04-26: data tables MUST be native, not shape grids
# ═══════════════════════════════════════════════════════════════════════════
def add_native_table(slide, x, y, col_widths, headers, rows, *,
                     header_fill=None, header_color=None, alt_fill=None,
                     header_h=Inches(0.26), row_h=Inches(0.30),
                     font_size=SIZE_TABLE_BODY, header_size=SIZE_TABLE_HEAD,
                     row_aligns=None, special_styles=None, palette=Palette):
    if header_fill is None: header_fill = palette.primary
    if header_color is None: header_color = palette.white
    if alt_fill is None: alt_fill = palette.primary_tint
    n_cols = len(col_widths)
    n_rows = 1 + len(rows)
    total_w = int(sum(col_widths))
    total_h = int(header_h + row_h * len(rows))
    tbl_shape = slide.shapes.add_table(n_rows, n_cols, x, y, total_w, total_h)
    tbl = tbl_shape.table
    for i, cw in enumerate(col_widths):
        tbl.columns[i].width = int(cw)
    tbl.rows[0].height = int(header_h)
    for i in range(len(rows)):
        tbl.rows[i + 1].height = int(row_h)
    tbl.first_row = False
    tbl.horz_banding = False
    tbl.vert_banding = False

    def style_cell(cell, text, opts, fill_color, header=False):
        cell.fill.solid()
        cell.fill.fore_color.rgb = fill_color
        cell.margin_left = Inches(0.08)
        cell.margin_right = Inches(0.08)
        cell.margin_top = Inches(0.04)
        cell.margin_bottom = Inches(0.04)
        cell.vertical_anchor = MSO_ANCHOR.MIDDLE
        tf = cell.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.alignment = opts.get('align', PP_ALIGN.LEFT) if not header else PP_ALIGN.LEFT
        p.line_spacing = 1.25
        run = p.add_run()
        run.text = text.upper() if header else text
        run.font.name = opts.get('font', FONT_DISPLAY)
        run.font.size = Pt(header_size if header else font_size)
        run.font.color.rgb = opts.get('color', header_color if header else palette.asphalt)
        run.font.bold = True if header else opts.get('bold', False)
        if header:
            rPr = run._r.get_or_add_rPr()
            rPr.set('spc', '180')

    for c, hdr in enumerate(headers):
        style_cell(tbl.cell(0, c), hdr, {}, header_fill, header=True)
    for r_idx, row in enumerate(rows):
        special = (special_styles or {}).get(r_idx, {})
        row_fill = special.get('fill', alt_fill if r_idx % 2 == 1 else palette.white)
        for c_idx, cell_data in enumerate(row):
            if isinstance(cell_data, tuple):
                text, opts = cell_data
            else:
                text, opts = cell_data, {}
            if 'align' not in opts and row_aligns:
                opts = {**opts, 'align': row_aligns[c_idx]}
            style_cell(tbl.cell(r_idx + 1, c_idx), text, opts, row_fill)
    return tbl_shape


# ═══════════════════════════════════════════════════════════════════════════
# SIGNATURE SLOT — pyramid layout for authorization pages
# ═══════════════════════════════════════════════════════════════════════════
def sig_slot(slide, x, y, w, h, role, name_holder, sub, *, palette=Palette):
    """Signature slot with role · name · subtitle · signature line.
    Min h=1.50 — gives ≥0.55 in clear space above the signature line for
    actual signing (per 2026-04-27 rule). Smaller heights produce a too-tight
    signing area and the document loses dignity in print."""
    add_rect(slide, x, y, w, h, fill=palette.accent_tint,
             line_color=palette.hairline, line_width=Pt(0.5))
    add_text(slide, x + Inches(0.16), y + Inches(0.14), w - Inches(0.32), Inches(0.16),
             role, size=SIZE_FOOT, color=palette.primary, bold=True,
             letter_spacing=LETTER_SPACING_EYEBROW, palette=palette)
    add_text(slide, x + Inches(0.16), y + Inches(0.34), w - Inches(0.32), Inches(0.22),
             name_holder, size=10.5, color=palette.asphalt, bold=True, palette=palette)
    add_text(slide, x + Inches(0.16), y + Inches(0.58), w - Inches(0.32), Inches(0.20),
             sub, size=SIZE_FOOT, color=palette.muted, palette=palette)
    line_y = y + h - Inches(0.42)
    add_line(slide, x + Inches(0.16), line_y, x + w - Inches(0.16), line_y,
             color=palette.asphalt, width=Pt(0.6))
    add_text(slide, x + Inches(0.16), line_y + Inches(0.08),
             w - Inches(0.32), Inches(0.18),
             "SIGNATURE · DATE", size=7, color=palette.muted, bold=True,
             letter_spacing=LETTER_SPACING_LABEL, palette=palette)


# ═══════════════════════════════════════════════════════════════════════════
# PRESENTATION SETUP
# ═══════════════════════════════════════════════════════════════════════════
def make_portrait_presentation():
    """Returns a Presentation pre-configured for A4 portrait layout."""
    from pptx import Presentation
    prs = Presentation()
    prs.slide_width = SLIDE_W
    prs.slide_height = SLIDE_H
    return prs


def add_blank_slide(prs):
    """Add a blank-layout slide. Use this for every charter page."""
    return prs.slides.add_slide(prs.slide_layouts[6])
