# Portrait A4 Builder — canonical look-and-feel for "PowerPoint Vertical"

**Status:** locked v6.2 (2026-04-27).
**Use whenever:** Moe asks for "PowerPoint vertical", "A4 portrait deck", "engagement charter", "signed authorization document", "portrait one-pager", or any printable sign-and-archive PPTX. The brand palette can change per project — the layout cannot.

---

## What this guarantees

The same quality bar across any future portrait PPTX, regardless of brand colors:

1. **A4 portrait canvas** (8.27 × 11.69 in) with PowerPoint-native slide-size set before content is added.
2. **Pure white page background** — locked. Print-and-sign documents must not carry full-page color.
3. **Gold (or accent-color) top bar** at 0.06 in.
4. **Eyebrow lifted to y=0.26 in** (was floating mid-zone in v6.0). Keeps the eye anchored to the top of the page.
5. **Charter-grade titles** — formal section names like "Project Organization." NOT marketing copy like "Who works on this · charged to this engagement." (See [Title rules](#title-rules) below.)
6. **No § symbol** — replaced with "Part X" or "Section X" prefix. Globally banned 2026-04-26.
7. **Native PowerPoint tables** for all data tables. Shape-grid tables are forbidden — they look like "shapes pretending to be a table" in print.
8. **Signature slots ≥ 1.50 in tall** with ≥ 0.55 in of clear vertical room above the signing line. Anything tighter is undignified.
9. **Body content uses `Resize shape to fit text` autofit** as a safety net — overflow grows the box visibly, never silently clips.
10. **Footer band** at 0.50 in with gold accent line above and page metadata.

---

## Canvas & zones (locked numbers)

| Element | Inches | Notes |
|---|---|---|
| Slide width | 8.27 | A4 = 210 mm |
| Slide height | 11.69 | A4 = 297 mm |
| Outer LR margin | **0.60** | trimmed from 0.75 on 2026-04-27 |
| Top gold bar | 0.06 | full-bleed |
| Title zone top | 0.50 | start of title rectangle |
| Title zone height | 1.40 | FIXED — content cannot bleed past |
| Eyebrow y | 0.26 | inside title zone, anchored to top |
| H1 y | 0.46 | below eyebrow |
| Lede y | 1.10 | above hairline |
| Hairline y | 1.93 | bottom of title zone |
| Body top | 1.95 | content begins here |
| Body bottom | 9.40 | end of standard body region |
| Signature zone | 9.40 → 10.70 | usable for sig pages |
| Footer top | 11.19 | dune band starts |
| Footer height | 0.50 | with gold accent line above |

Body width = 7.07 in (slide_w − 2 × outer_lr).
Two-column grid = 3.355 in each column with 0.36 in gutter.

---

## Title rules

**Eyebrow** (uppercase · 8.5 pt · 200 hpt letter-spacing · primary color):
> `PART C.1 — SERVICE CATALOG`

**H1** (20 pt · bold · asphalt · charter-grade):
> `Delivery Services.`

**Lede** (10 pt · muted · 1.45 line-spacing — context, not marketing):
> `Sub-service-level selection. Tick = in scope · empty = explicitly out of scope. Selection is binding under Part I.`

**Bad H1 examples — NEVER produce these:**
- "What SMC builds & operates · client ticks what's in scope." (marketing copy)
- "Who decides · how scope changes · when to escalate." (descriptive question)
- "When · how much · what could break it." (clever-clever)
- "One X. One Y. One Z." (tricolon — banned site-wide per memory rule)

**Good H1 examples — replicate this voice:**
- "Delivery Services."
- "Engagement Assumptions & Client Responsibilities."
- "Project Organization."
- "Schedule, Commercial Envelope & Strategic Risks."
- "Document Operating System."
- "Authorization."

The H1 tells the reader **what part of the document this is**. It is a heading, not a promise.

---

## Section references — no `§` symbol

The `§` (section sign) character is **banned** across SMC portrait output (Moe rule, 2026-04-26). Any prior templates carrying `§` should be updated. Use:

- `Part A`, `Part B`, … for major sections.
- `Part C.1`, `Part D.2`, … for sub-sections.
- `Section A` is acceptable in long body sentences.
- `(Part J item 09)` for cross-references.

---

## Tables — must be native

Per Moe rule (2026-04-26), data tables MUST be created via `slide.shapes.add_table(...)`, not as grids of rectangles + text boxes. Native tables:

- Render with proper grid lines and cell borders in print.
- Are editable as tables in PowerPoint (insert/delete row, sort, etc.).
- Auto-flow text within cells with proper word-wrap.
- Look like a table; shape grids look like "shapes pretending to be a table."

The `add_native_table()` helper in `python/smc_portrait.py` styles tables consistently:
- Header row: primary color fill, white text, 8 pt bold, 180 hpt letter-spacing, uppercase.
- Body rows: alternate primary-tint / white fill.
- Row height: 0.30 in default, 0.36 in for content that wraps to two lines.

---

## Signature slots — give actual room to sign

Each signature slot must be **≥ 1.50 in tall** (locked 2026-04-27). Inside:

| Position | Content | Style |
|---|---|---|
| y + 0.14 | Role label | 8 pt · primary · bold · uppercase · 200 hpt spacing |
| y + 0.34 | `[Name]` placeholder | 10.5 pt · asphalt · bold |
| y + 0.58 | Subtitle (org/role context) | 8 pt · muted |
| y + (h − 0.42) | **Signature line** (asphalt rule) | 0.6 pt thick |
| y + (h − 0.34) | "SIGNATURE · DATE" caption | 7 pt · muted · 180 hpt spacing |

The 0.42 in offset from bottom + line position from top = ≥ 0.55 in of clear vertical space above the signing line. That's the **signing room**. Anything less feels cramped on paper.

### Default 2-2-2-1 pyramid layout (engagement charters)

| Row | Slots | Content |
|---|---|---|
| 1 | 2 | Event Director · EPMO Portfolio Manager |
| 2 | 2 | COO · CCO |
| 3 | 2 | CFO · CSSO |
| 4 | 1 (centered) | CEO |

The 4-row pyramid ends with the CEO alone — final authorization. Width per slot = (BODY_W − 0.20) / 2. CEO row uses the same width as a paired slot for visual balance.

---

## Body containers

### `tile()`

Generic tile = outline rectangle + optional left-accent stripe + optional title + body. Body uses `MSO_AUTO_SIZE.SHAPE_TO_FIT_TEXT` so wrapping cannot silently clip. **Always size the rectangle generously** — if text grows beyond the rect, that's a visual signal to enlarge h on the next iteration.

### `bullet_tile()`

Tile with a list of bullet items, each prefixed with `→ ` (Unicode arrow). 9.5 pt body, 1.30 line-spacing, 2 pt space-before. Generous height needed when items wrap.

### `lbl()`

Section eyebrow (uppercase · 8.5 pt · 200 hpt spacing · primary color), with optional muted suffix to the right. When a suffix is supplied, the label box is narrowed to 2.65 in so the two text frames don't collide.

---

## Color palette

The default palette is SMC v6.1 (locked colors: `#00625B` dark teal, `#009667` forest green). For any non-SMC brand, **subclass `Palette`** in `python/smc_portrait.py` and pass the new class to component builders:

```python
from smc_portrait import Palette
from pptx.dml.color import RGBColor

class MoXPalette(Palette):
    primary       = RGBColor(0x10, 0x10, 0x10)  # MoX black
    accent        = RGBColor(0xFF, 0x80, 0x40)  # MoX orange
    primary_tint  = RGBColor(0xF5, 0xF5, 0xF5)
    # ... only override the colors you need; rest inherits from SMC defaults

slide_chrome(slide, "Page label", "Page 1 / 9", palette=MoXPalette)
```

The layout rules above apply unchanged; only the colors swap.

---

## How to use the builder

```python
from smc_portrait import (
    make_portrait_presentation, add_blank_slide,
    add_chrome, add_title, add_title_band,
    lbl, tile, bullet_tile, add_native_table, sig_slot,
    Palette, OUTER_LR, BODY_W, BODY_TOP, BODY_BOTTOM,
)
from pptx.util import Inches, Pt

prs = make_portrait_presentation()
s = add_blank_slide(prs)

add_title(s, "Part C.1 — Service Catalog", "Delivery Services.",
          "Sub-service-level selection. Tick = in scope · empty = out.",
          meta_r="ENG-MOS-027 · v1.0")
# ... body content ...
add_chrome(s, "SMC · Master-Planning Charter · Part C.1", "Page 2 / 9")

prs.save("Output.pptx")
```

---

## Validation — every portrait build must pass

1. **A4 portrait** — `prs.slide_width == Inches(8.27)`, `prs.slide_height == Inches(11.69)`.
2. **Bounds clean** — no shape with negative dimensions, no shape extending past slide edges.
3. **Pure white pages** — no full-page color fills.
4. **Native tables** — every data table is `slide.shapes.add_table(...)`, not a shape grid.
5. **No `§`** — grep the saved XML; should not appear.
6. **Sigs ≥ 1.50 in tall** on authorization pages.
7. **Eyebrow at y=0.26**, h1 at y=0.46.
8. **Charter-grade H1** — no marketing copy, no tricolon ("X · Y · Z" headlines), no "client ticks" / "what's in scope" / "who decides" patterns.

QA script template: see `python/smc_portrait.py` companion `qa_charter.py` pattern from the v6.2 reference build (`SMC Transformation/_transient/2026-04-26-ip-charter-options/qa_charter.py`).

---

## Origin & change log

| Date | Change |
|---|---|
| 2026-04-26 | v6.1 Portrait A4 introduced — A4 canvas, dune-band cover, hairline title, 3-col GANTT, far-left riser org wide. |
| 2026-04-26 | Page background locked to pure white #FFFFFF (print/sign/archive rule). |
| 2026-04-26 | "§" symbol banned globally; replaced with "Part X" prefix. |
| 2026-04-26 | Native PPT tables required for all data tables (Moe rule). |
| 2026-04-26 | Eyebrow lifted to y=0.26 (was floating at y=0.50 mid-zone). |
| 2026-04-26 | Charter-grade H1 voice locked (no marketing copy). |
| 2026-04-27 | Outer LR margin trimmed 0.75 → 0.60 (≈20%) for more horizontal room. |
| 2026-04-27 | Signature slot height ≥ 1.50 in with ≥ 0.55 in clear above signing line. |
| 2026-04-27 | Default sig pyramid locked: 2-2-2-1 (ED+EPMO → 4 chiefs paired → CEO alone). |
| 2026-04-27 | Canonical Python builder extracted to `python/smc_portrait.py`. |
| 2026-04-27 | This guideline doc created — single source of truth for portrait quality. |
