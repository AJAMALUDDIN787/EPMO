# UI Kits

SMC's brand scope in the supplied guideline (`SMC_Brand_Guideline_new.pptx`, v5.0 · 2026) is presentation and physical/digital brand applications, not a software product. There is no app, dashboard, or marketing website source code in this project.

**As a result, no UI kit is included.** Slide templates live in `slides/` and function as the product deliverable for this system.

If SMC has a website, operations dashboard, or fan-facing app you'd like included, please attach the codebase or a Figma link and a dedicated UI kit will be added here.
