# Fonts

SMC's brand fonts are commercial and not redistributable here:

- **Century Gothic** — all English copy
- **Sakkal Majalla** — all Arabic copy (+2–4pt vs English equivalent)
- **Rotunda + Cairo** — used in the logo wordmark only

## Fallbacks in use

This system falls back to open-source Google Fonts that match the geometric-humanist character of the originals:

| Brand font | Fallback | Rationale |
|---|---|---|
| Century Gothic | **Jost** | Modern geometric-humanist; open apertures, similar proportions |
| Sakkal Majalla | **Cairo** | Naskh-based, supports Latin + Arabic, bilingual pairing |

## Drop-in upgrade

Place licensed `.woff2` files here and uncomment the `@font-face` block in `colors_and_type.css`:

```
fonts/
  CenturyGothic.woff2
  CenturyGothic-Bold.woff2
  SakkalMajalla.woff2
  SakkalMajalla-Bold.woff2
```

The rest of the system references `var(--font-display)` / `var(--font-body)` / `var(--font-arabic)` and will pick up the licensed files automatically once the `@font-face` is active.
